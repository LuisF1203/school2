#ifndef STATS_H_
#define STATS_H_

int menu(void);
int min(char*);
int es(char*);
int P(char*);
int mayusStart(char*);
int gerundWords(char*);
int bus(char*,char*);
int minMay(char*);

#endif /* STATS_H_ */